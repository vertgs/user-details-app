import React, { Component } from "react";
import UserDataService from "../services/user.service";
import { confirmAlert } from 'react-confirm-alert';
import SimpleReactValidator from 'simple-react-validator';

export default class User extends Component {
  constructor(props) {
    super(props);
    this.validator = new SimpleReactValidator({autoForceUpdate: this});
    this.submitUpdateForm = this.submitUpdateForm.bind(this);
    this.onChangeName = this.onChangeName.bind(this);
    this.getUser = this.getUser.bind(this);
    this.updateUser = this.updateUser.bind(this);
    this.deleteUser = this.deleteUser.bind(this); 
    this.onChangeEmail = this.onChangeEmail.bind(this);
    this.onChangeUserId = this.onChangeUserId.bind(this);
    this.onChangePhoto = this.onChangePhoto.bind(this);

    this.state = {
      currentUser: {
        id: null,
        userId: "",
        name: "",
        email:"",
        photo:"",
        fileUploadedUri:"",
      }
    };
  }

  componentDidMount() {
    this.getUser(this.props.match.params.id);
  }

  onChangeUserId(e) {
    const userId = e.target.value;

    this.setState(function(prevState) {
      return {
        currentUser: {
          ...prevState.currentUser,
          userId: userId
        }
      };
    });
  }

  onChangeName(e) {
    const name = e.target.value;
    
    this.setState(prevState => ({
      currentUser: {
        ...prevState.currentUser,
        name: name
      }
    }));
  }

  onChangeEmail(e) {
    const email = e.target.value;
    
    this.setState(prevState => ({
      currentUser: {
        ...prevState.currentUser,
        email: email
      }
    }));
  }

  onChangePhoto(e) {
    const photo = e.target.value;
    
    this.setState(prevState => ({
      currentUser: {
        ...prevState.currentUser,
        photo: photo
      }
    }));
    this.upload(e);
  }

  submitUpdateForm(){
    if (this.validator.allValid()) {
      this.updateUser();
    } else {
      this.validator.showMessages();      
    }
  }

  upload(event) {
    let file = event.target.files[0];
    let  c_currentUser= this.state.currentUser;
    UserDataService.upload(file,this.state.currentUser.userId)
        .then((response) => {
          this.setState({
            currentUser:{
              photo: response.data.fileDownloadUri,
              id: c_currentUser.id,
              userId: c_currentUser.userId,
              name: c_currentUser.name,
              email: c_currentUser.email,
            }
          });
        })
        .catch((err) => {
          this.setState({          
            fileDownloadUri: ''
          });
         console.log(err);
        });
  }

  getUser(id) {
    UserDataService.get(id)
      .then(response => {
        this.setState({
          currentUser: response.data
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  }

  
  updateUser() {
    UserDataService.update(
      this.state.currentUser.id,
      this.state.currentUser
    )
      .then(response => {
        console.log(response.data);
        this.successMsg();
       
      })
      .catch(e => {
        console.log(e);
        this.errorMsg();
      });
  }

  deleteUser() {    
    UserDataService.delete(this.state.currentUser.id)
      .then(response => {
        console.log(response.data);
        this.props.history.push('/users');
      })
      .catch(e => {
        console.log(e);
      });
  }

  deleteSubmit = () => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <h1>Are you sure?</h1>
            <p>You want to delete this user</p>
            <button onClick={onClose}>No</button>
            <button
              onClick={() => {
                this.deleteUser();
                onClose();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      }
    });
  }

  successMsg = () => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <p>User Updated successfully!</p>
            <button onClick={onClose}>Ok</button>            
          </div>
        );
      }
    });
  }

  errorMsg = () => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <p>Error in User Updation!</p>
            <button onClick={onClose}>Ok</button>            
          </div>
        );
      }
    });
  }

  render() {
    const { currentUser } = this.state;

    return (
      <div className="editContainer">

        {currentUser ? (
          <div className="edituser" >
            <div className="col-sm-12 userHead"><h4>Edit User</h4></div>
          
            <div className="form-group">
              <label htmlFor="userId" class="control-label col-sm-2" >User Id</label>
              <div class="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  id="userId"
                  value={currentUser.userId}
                  onChange={this.onChangeUserId}
                  name="userId"
                />
                {this.validator.message('userId', this.state.currentUser.userId, 'required')}
                </div>
            </div>

            <div className="form-group">
              <label htmlFor="name" class="control-label col-sm-2">Name</label>
              <div class="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  id="name"
                  value={currentUser.name}
                  onChange={this.onChangeName}
                  name="name"
                />
                {this.validator.message('name', this.state.currentUser.name, 'required')}
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="email" class="control-label col-sm-2">Email</label>
              <div class="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  id="email"
                  value={currentUser.email}
                  onChange={this.onChangeEmail}
                  name="email"
                />
                {this.validator.message('email', this.state.currentUser.email, 'required|email')}
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="photo" class="control-label col-sm-2">Photo</label>
              <div class="col-sm-10">
              <input
                  type="text"
                  className="form-control photoTxt"
                  id="disPhoto"
                  readOnly
                  value={currentUser.photo}
                  name="disPhoto"
                />
                <input
                  type="file"
                  className="form-control photoUpload"
                  id="photo"                  
                  onChange={this.onChangePhoto}
                  name="photo"
                />
                {this.validator.message('photo', this.state.currentUser.photo, 'required')}
              </div>
            </div>

            <div className="form-group editButDiv">            

              <button
                type="submit"
                className="btn btn-primary btn-sm"
                onClick={this.submitUpdateForm}
              >
                Update
              </button>
                &nbsp;&nbsp;
              <button
                className="btn btn-danger btn-sm"
                onClick={this.deleteSubmit}>
                Delete
              </button>

            </div>          

          </div>
        ) : (<div>Data Not Found</div>)}

      </div>
    );
  }
}
