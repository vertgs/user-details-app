import React, { Component } from "react";
import UserDataService from "../services/user.service";
import { Link } from "react-router-dom";
import { confirmAlert } from 'react-confirm-alert';

export default class User extends Component {
  constructor(props) {
    super(props);
    this.getUser = this.getUser.bind(this);
    this.deleteUser = this.deleteUser.bind(this); 

    this.state = {
      user: {
        id: null,
        userId: "",
        name: "",
        email: "",
        photo: ""
      }
    };
  }

  componentDidMount() {
    this.getUser(this.props.match.params.id);
  }

  getUser(id) {
    UserDataService.get(id)
      .then(response => {
        this.setState({
          user: response.data
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  }

  
  deleteUser() {    
    UserDataService.delete(this.state.user.id)
      .then(response => {
        console.log(response.data);
        this.props.history.push('/users')
      })
      .catch(e => {
        console.log(e);
      });
  }

  deleteSubmit = () => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <h1>Are you sure?</h1>
            <p>You want to delete this user</p>
            <button onClick={onClose}>No</button>
            <button
              onClick={() => {
                this.deleteUser();
                onClose();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      }
    });
  }


  render() {
    const { user } = this.state;

    return (
      <div className="viewContainer">

        {user ? (

        <div class="viewuser table-responsive">
          
          <div className="col-sm-12 userHead"><h4>View User</h4></div>

          <table class="table table-hover">            
            <tbody>
               <tr>
                  <td width="200">
                  <img src={user.photo} class="rounded" alt={user.name} height="180" width="180"/>
                  </td>
                  <td>
                    <table class="subTable">
                    <tr>
                      <td className="right-align">User ID:</td><td className="info">{user.userId}</td>
                    </tr>
                    <tr>
                      <td className="right-align">Name:</td><td className="info">{user.name}</td>
                    </tr>
                    <tr>
                      <td className="right-align">Email:</td>
                      <td className="emailInfo"><u>{user.email}</u></td>
                    </tr>
                    <tr>
                      <td className="right-align">
                        <Link to={`/edit/${user.id}`} className="btn btn-warning btn-sm" > Edit </Link>
                      </td>
                      <td><button className="btn btn-danger btn-sm mr-2" onClick={this.deleteSubmit}>Delete</button></td>
                    </tr>                    
                    </table>                  
                    
                    </td>
                </tr>               
            </tbody>
          </table>
          
        </div>                 

        ) : (<div>Data Not Found</div>)}

      <div className="borderDiv"></div>

      </div>
    );
  }
}
