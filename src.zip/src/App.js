import React, { Component } from "react";
import { Switch, Route, Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";

import UsersList from "./components/userList.component";
import AddUser from "./components/addUser.component";
import EditUser from "./components/editUser.component";
import User from "./components/user.component";

class App extends Component {
  render() {
    return (
      <div>
        <nav className="navbar navbar-expand navbar-dark bg-dark">
          
          <div className="navbar-nav mr-auto">
            <li className="nav-item">
              <Link to={"/users"} className="nav-link">
                Users
              </Link>
            </li>
            <li className="nav-item">
              <Link to={"/add"} className="nav-link">
                Add
              </Link>
            </li>
          </div>
        </nav>

        <div className="container-fluid">
          <Switch>
            <Route exact path={["/", "/users"]} component={UsersList} />
            <Route exact path="/add" component={AddUser} />
            <Route exact path={["/users/:id"]} component={User} />   
            <Route exact path={["/edit/:id"]} component={EditUser} />         
          </Switch>
        </div>
      </div>
    );
  }
}

export default App;