import React, { Component } from "react";
import UserDataService from "../services/user.service";
import { Link } from "react-router-dom";

export default class User extends Component {
  constructor(props) {
    super(props);
    this.getUser = this.getUser.bind(this);
    this.deleteUser = this.deleteUser.bind(this); 

    this.state = {
      user: {
        id: null,
        userId: "",
        name: "",
        email: "",
        photo: ""
      }
    };
  }

  componentDidMount() {
    this.getUser(this.props.match.params.id);
  }

  getUser(id) {
    UserDataService.get(id)
      .then(response => {
        this.setState({
          user: response.data
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  }

  
  deleteUser() {    
    UserDataService.delete(this.state.user.id)
      .then(response => {
        console.log(response.data);
        this.props.history.push('/users')
      })
      .catch(e => {
        console.log(e);
      });
  }

  render() {
    const { user } = this.state;

    return (
      <div>

        {user ? (

        <div class="table-responsive">
          
          <h4>View User</h4>

          <table class="table table-hover">            
            <tbody>
               <tr>
                  <td>User Id</td><td>{user.userId}</td>
                </tr>
                <tr>
                  <td>Name</td><td>{user.name}</td>
                </tr>
                <tr>
                  <td>Email</td><td>{user.email}</td>
                </tr>
                <tr>
                  <td>Photo</td><td><img src={user.photo} class="img-thumbnail" alt={user.name}/></td>
                </tr>
                <tr>
                  <td>
                    <button className="badge badge-danger mr-2" onClick={this.deleteUser}>Delete</button>
                  </td>
                  <td><Link to={`/edit/${user.id}`} className="edit-link badge badge-warning" > Edit </Link></td>
                </tr>
            </tbody>
          </table>
        </div>


        ) : (<div>Data Not Found</div>)}


      </div>
    );
  }
}
