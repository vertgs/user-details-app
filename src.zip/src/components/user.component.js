import React, { Component } from "react";
import UserDataService from "../services/user.service";
import { Link } from "react-router-dom";

export default class User extends Component {
  constructor(props) {
    super(props);
    this.getUser = this.getUser.bind(this);
    this.deleteUser = this.deleteUser.bind(this); 

    this.state = {
      user: {
        id: null,
        userId: "",
        name: "",
        email: "",
        photo: ""
      }
    };
  }

  componentDidMount() {
    this.getUser(this.props.match.params.id);
  }

  getUser(id) {
    UserDataService.get(id)
      .then(response => {
        this.setState({
          user: response.data
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  }

  
  deleteUser() {    
    UserDataService.delete(this.state.user.id)
      .then(response => {
        console.log(response.data);
        this.props.history.push('/users')
      })
      .catch(e => {
        console.log(e);
      });
  }

  render() {
    const { user } = this.state;

    return (
      <div className="editContainer">

        {user ? (

        <div class="edituser table-responsive">
          
          <div className="col-sm-12 userHead"><h4>View User</h4></div>

          <table class="table table-hover">            
            <tbody>
               <tr>
                  <td width="200">
                  <img src={user.photo} class="img-thumbnail" alt={user.name} height="200" width="200"/>
                  </td>
                  <td>
                    <table class="subTable">
                    <tr>
                      <td className="right-align">User ID:</td><td className="info">{user.userId}</td>
                    </tr>
                    <tr>
                      <td className="right-align">Name:</td><td className="info">{user.name}</td>
                    </tr>
                    <tr>
                      <td className="right-align">Email:</td>
                      <td className="emailInfo"><a href="">{user.email}</a></td>
                    </tr>
                    <tr>
                      <td className="right-align">
                        <Link to={`/edit/${user.id}`} className="edit-link badge badge-warning" > Edit </Link>
                      </td>
                      <td><button className="badge badge-danger mr-2" onClick={e =>
                                  window.confirm("Are you sure you wish to delete this user?") &&
                                  this.deleteUser()
                              }>Delete</button></td>
                    </tr>                    
                    </table>                  
                    
                    </td>
                </tr>               
            </tbody>
          </table>
        </div>

        ) : (<div>Data Not Found</div>)}


      </div>
    );
  }
}
