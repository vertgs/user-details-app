import React, { Component } from "react";
import UserDataService from "../services/user.service";
import "bootstrap/dist/css/bootstrap.min.css";

export default class AddUser extends Component {
  constructor(props) {
    super(props);
    this.onChangeUserId = this.onChangeUserId.bind(this);
    this.onChangeName = this.onChangeName.bind(this);
    this.onChangeEmail = this.onChangeEmail.bind(this);
    this.onChangePhoto = this.onChangePhoto.bind(this);
    this.saveUser = this.saveUser.bind(this);
    this.newUser = this.newUser.bind(this);
    this.upload = this.upload.bind(this);

    this.state = {
      id: null,
      userId: "",
      name: "",
      email:"",
      photo:"",
      fileUploadedUri:"",
    };
  }

  onChangeUserId(e) {
    this.setState({
        userId: e.target.value
    });
  }

  onChangeName(e) {
    this.setState({
      name: e.target.value
    });
  }

  onChangeEmail(e) {
    this.setState({
      email: e.target.value
    });
  }

  onChangePhoto(e) {
    this.setState({
      photo: e.target.value
    });
    this.upload(e);
  }
  
  saveUser() {
    var data = {
      userId: this.state.userId,
      name: this.state.name,
      email: this.state.email,
      photo: this.state.fileUploadedUri,
    };

    UserDataService.create(data)
      .then(response => {
        this.setState({
          id: response.data.id,
          userId: response.data.userId,
          name: response.data.name,
          email: response.data.email,
          photo: response.data.photo,
          submitted: true
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  }

  upload(event) {
    let file = event.target.files[0];
    UserDataService.upload(file,this.state.userId)
        .then((response) => {
          this.setState({
            fileUploadedUri: response.data.fileDownloadUri
          });
        })
        .catch((err) => {
          this.setState({          
            fileDownloadUri: ''
          });
         console.log(err);
        });
  }

  newUser() {
    this.setState({
      id: null,
      userId: "",
      name: "",
      email: "",
      photo: "",
      fileUploadedUri:"",
      submitted: false
    });
  }

  render() {
    return (
      
      <div>
        {this.state.submitted ? (
          <div>
            <h4>You submitted successfully!</h4>
            <button className="btn btn-success" onClick={this.newUser}>
              Add
            </button>
          </div>
        ) : (
          <form className="form-horizontal col-md-12">

            <div className="form-group">
              <label htmlFor="userId" className="control-label col-sm-2" >User Id</label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  id="userId"
                  required
                  value={this.state.userId}
                  onChange={this.onChangeUserId}
                  name="userId"
                />
                </div>
            </div>

            <div className="form-group">
              <label htmlFor="name" className="control-label col-sm-2">Name</label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  id="name"
                  required
                  value={this.state.name}
                  onChange={this.onChangeName}
                  name="name"
                />
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="email" className="control-label col-sm-2">Email</label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  id="email"
                  required
                  value={this.state.email}
                  onChange={this.onChangeEmail}
                  name="email"
                />
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="photo" className="control-label col-sm-2">Photo</label>
              <div className="col-sm-10">
                <input
                  type="file"
                  className="form-control"
                  id="photo"
                  required
                  value={this.state.photo}
                  onChange={this.onChangePhoto}
                  name="photo"
                />
              </div>
            </div>
            
            <div className="form-group">
              <div className="col-sm-offset-2 col-sm-10 pad-top-10">
                <button onClick={this.saveUser} className="btn btn-success">
                  Submit
                </button>
              </div>
            </div>           
          </form> 
        )}
      </div>
      
    );
  }
}
