import React, { Component } from "react";
import UserDataService from "../services/user.service";

export default class User extends Component {
  constructor(props) {
    super(props);
    this.onChangeName = this.onChangeName.bind(this);
    this.getUser = this.getUser.bind(this);
    this.updateUser = this.updateUser.bind(this);
    this.deleteUser = this.deleteUser.bind(this); 
    this.onChangeEmail = this.onChangeEmail.bind(this);
    this.onChangeUserId = this.onChangeUserId.bind(this);
    this.onChangePhoto = this.onChangePhoto.bind(this);

    this.state = {
      currentUser: {
        id: null,
        userId: "",
        name: "",
        email:"",
        photo:"",
        fileUploadedUri:"",
      },
      message: ""
    };
  }

  componentDidMount() {
    this.getUser(this.props.match.params.id);
  }

  onChangeUserId(e) {
    const userId = e.target.value;

    this.setState(function(prevState) {
      return {
        currentUser: {
          ...prevState.currentUser,
          userId: userId
        }
      };
    });
  }

  onChangeName(e) {
    const name = e.target.value;
    
    this.setState(prevState => ({
      currentUser: {
        ...prevState.currentUser,
        name: name
      }
    }));
  }

  onChangeEmail(e) {
    const email = e.target.value;
    
    this.setState(prevState => ({
      currentUser: {
        ...prevState.currentUser,
        email: email
      }
    }));
  }

  onChangePhoto(e) {
    const photo = e.target.value;
    
    this.setState(prevState => ({
      currentUser: {
        ...prevState.currentUser,
        photo: photo
      }
    }));
    this.upload(e);
  }

  upload(event) {
    let file = event.target.files[0];
    let  c_currentUser= this.state.currentUser;
    UserDataService.upload(file,this.state.currentUser.userId)
        .then((response) => {
          this.setState({
            currentUser:{
              photo: response.data.fileDownloadUri,
              id: c_currentUser.id,
              userId: c_currentUser.userId,
              name: c_currentUser.name,
              email: c_currentUser.email,
            }
          });
        })
        .catch((err) => {
          this.setState({          
            fileDownloadUri: ''
          });
         console.log(err);
        });
  }

  getUser(id) {
    UserDataService.get(id)
      .then(response => {
        this.setState({
          currentUser: response.data
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  }

  
  updateUser() {
    UserDataService.update(
      this.state.currentUser.id,
      this.state.currentUser
    )
      .then(response => {
        console.log(response.data);
        this.setState({
          message: "The user details updated successfully!"
        });
      })
      .catch(e => {
        console.log(e);
      });
  }

  deleteUser() {    
    UserDataService.delete(this.state.currentUser.id)
      .then(response => {
        console.log(response.data);
        this.props.history.push('/users')
      })
      .catch(e => {
        console.log(e);
      });
  }

  render() {
    const { currentUser } = this.state;

    return (
      <div className="editContainer">

        {currentUser ? (
          <div className="edituser" >
            <div className="col-sm-12 userHead"><h4>Edit User</h4></div>
          
            <div className="form-group">
              <label htmlFor="userId" class="control-label col-sm-2" >User Id</label>
              <div class="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  id="userId"
                  required
                  value={currentUser.userId}
                  onChange={this.onChangeUserId}
                  name="userId"
                />
                </div>
            </div>

            <div className="form-group">
              <label htmlFor="name" class="control-label col-sm-2">Name</label>
              <div class="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  id="name"
                  required
                  value={currentUser.name}
                  onChange={this.onChangeName}
                  name="name"
                />
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="email" class="control-label col-sm-2">Email</label>
              <div class="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  id="email"
                  required
                  value={currentUser.email}
                  onChange={this.onChangeEmail}
                  name="email"
                />
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="photo" class="control-label col-sm-2">Photo</label>
              <div class="col-sm-10">
              <input
                  type="text"
                  className="form-control photoTxt"
                  id="disPhoto"
                  readOnly
                  value={currentUser.photo}
                  name="disPhoto"
                />
                <input
                  type="file"
                  className="form-control photoUpload"
                  id="photo"
                  required
                  onChange={this.onChangePhoto}
                  name="photo"
                />
              </div>
            </div>

            <div className="form-group editButDiv">
            <button
              className="badge badge-danger mr-2"
              onClick={this.deleteUser}
            >
              Delete
            </button>

            <button
              type="submit"
              className="badge badge-success"
              onClick={this.updateUser}
            >
              Update
            </button>
            </div>
            <p>{this.state.message}</p>

          </div>
        ) : (<div>Data Not Found</div>)}

      </div>
    );
  }
}
