import React, { Component } from "react";
import UserDataService from "../services/user.service";
import { Link } from "react-router-dom";
import Pagination from "@material-ui/lab/Pagination";

export default class UsersList extends Component {
  constructor(props) {
    super(props);
    this.retrieveUsers = this.retrieveUsers.bind(this);
    this.setActiveUser = this.setActiveUser.bind(this);
    this.refreshList = this.refreshList.bind(this);
    this.deleteUser = this.deleteUser.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);
    this.handlePageSizeChange = this.handlePageSizeChange.bind(this);


    this.state = {
      users: [],
      currentUser: null,
      page: 1,
      count: 0,
      pageSize: 5,
    };
    this.pageSizes = [5, 10, 15];
  }

  componentDidMount() {
    this.retrieveUsers();
  }

  getRequestParams( page, pageSize) {
    let params = {};

    if (page) {
      params["page"] = page - 1;
    }

    if (pageSize) {
      params["size"] = pageSize;
    }

    return params;
  }

  refreshList() {
    this.retrieveUsers();
    this.setState({
      currentUsers: null,
    });
  }
  
  deleteUser(id) {    
    UserDataService.delete(id)
      .then(response => {
        console.log(response.data);
        this.retrieveUsers();
      })
      .catch(e => {
        console.log(e);
      });
  }

  retrieveUsers() {

    const { page, pageSize } = this.state;
    const params = this.getRequestParams(page, pageSize);

    UserDataService.getAll(params)
      .then(response => {
        const { users, totalPages } = response.data;
        this.setState({
          users: users,
          count: totalPages,
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });      
  }

  setActiveUser(user, index) {
    this.setState({
      currentUser: user
    });
  }

  handlePageChange(event, value) {
    this.setState(
      {
        page: value,
      },
      () => {
        this.retrieveUsers();
      }
    );
  }

  handlePageSizeChange(event) {
    this.setState(
      {
        pageSize: event.target.value,
        page: 1
      },
      () => {
        this.retrieveUsers();
      }
    );
  }

   render() {

    const {
      users,
      page,
      count,
      pageSize,
    } = this.state;

    return (
      <div className="container-fluid">
        
        <div className="col-md-6">
          <h4>Users List</h4>          


          <div class="table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>User Id</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Photo</th>
                  <th></th><th></th><th></th>
                </tr>
              </thead>
              <tbody>
                {users &&
                users.map((user, index) => (
                  <tr>
                    <td>{user.userId}</td><td>{user.name}</td><td>{user.email}</td>
                    <td><img src={user.photo} class="img-thumbnail" alt={user.name}/></td>                    
                    <td><Link to={`/users/${user.id}`}  className="edit-link badge badge-warning" > View </Link></td>
                    <td><Link to={`/edit/${user.id}`} className="edit-link badge badge-warning" > Edit </Link></td>
                    <td><a onClick={() => this.deleteUser(user.id)} href='javascript:void(0);' className="edit-link badge badge-warning" > Delete </a></td>
                  </tr>
                ))}                
              </tbody>
            </table>
          </div>

          <Pagination
              className="my-3"
              count={count}
              page={page}
              siblingCount={1}
              boundaryCount={1}
              variant="outlined"
              shape="rounded"
              onChange={this.handlePageChange}
            />

          <div className="mt-3">
            {"Page: "}
            <select onChange={this.handlePageSizeChange} value={pageSize}>
              {this.pageSizes.map((size) => (
                <option key={size} value={size}>
                  {size}
                </option>
              ))}
            </select>            
          </div>
          
        </div>        
      </div>
    );
  }

}