import http from "../http-common";

class UserDataService {
  getAll(params) {
    return http.get("/users",{ params });
  }

  get(id) {
    return http.get(`/users/${id}`);
  }

  create(data) {
    return http.post("/users", data);
  }

  update(id, data) {
    return http.put("/users", data);
  }

  delete(id) {
    return http.delete(`/users/${id}`);
  }

}

export default new UserDataService();