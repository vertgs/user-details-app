import http from "../http-common";

class UserDataService {
  getAll(params) {
    return http.get("/v1/users",{ params });
  }

  get(id) {
    return http.get(`/v1/users/${id}`);
  }

  create(data) {
    return http.post("/v1/users", data);
  }

  update(id, data) {
    return http.put("/v1/users", data);
  }

  delete(id) {
    return http.delete(`/v1/users/${id}`);
  }

  upload(file, fileName) {
    let formData = new FormData();
    formData.append("file", file);
    formData.append("fileName", fileName);

    return http.post("/upload", formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
  }

}

export default new UserDataService();